# 7S syntetiskt dataset + format-spec — HvSS Vällinge (övning)

Tre tydligt åtskilda delar ("bins"):

## Bin 1 — Data-mimik (det här paketets kärna)
Härmar den **centrala applikationen** (Signal → formaterat 7S Markdown). Skapar
realistiska testmeddelanden att utveckla mot. Skapar **inga** entitetsnoter och
gör **ingen** analys — bara rena, korrekt länkade meddelanden.

- `generate_reports.py` — genererar ~300 syntetiska 7S-rapporter (deterministiskt,
  frö 1947) till `reports/`. Inbäddad "ground truth": brus, pendlare
  (falsk-positiv-fälla) och en spaningscell vars sammanhang måste *härledas* ur
  länkarna — inte serveras färdigt.
- `feed_reports.py` — interaktiv matare som droppar rapporter i vaulten i
  tidsordning, som applikationen skulle göra när meddelanden anländer.
- `ground_truth.json` — facit (per fil: id, tnr, tidpunkt, truth) för att mäta
  träffsäkerhet i analyssteget.

```
python3 generate_reports.py
python3 feed_reports.py --source ./reports --vault /sökväg/till/Vault
```
Matarkommandon: `send` / `send 2` / `auto` (~15 min) / `auto 5` / `status` /
`reset` / `quit`.

## Bin 2 — Obsidian-konfiguration (inga skript)
Rena inställningar för en användare som tittar på data:
- **Graffärger:** Graph view → gear → Groups. `["typ":"entitet"]` ljus,
  `["typ":"7S-rapport"]` grå. (Eller tagg-baserat när entiteter finns.)
  Nodstorlek efter länkar lyfter återkommande entiteter.
- **Karta:** community-plugin "Map View". Kräver kombinerad koordinat —
  se FORMAT_SPEC.md §8. Testdatat innehåller redan `location: "lat,lon"`, så
  kartnålar fungerar direkt: aktivera Map View och välj `location` som
  koordinategenskap.
- **Egenskaper:** Editor → "Properties in document" → *Hidden* så rapporttexten
  syns rent.
- **Skapa entitet för hand:** skriv `[[Namn]]` i en rapport; klicka för att skapa
  noten. Sätt "Default location for new notes" till en `entities`-mapp och använd
  kärn-pluginet Templates för en `Entitet`-mall. Entitetsnoter bär *identitet*
  (typ, slag, tagg) — **inte** tid/plats (de hör till observationen, och en
  entitet ses i flera rapporter).

## Bin 3 — Plugin (ej påbörjad)
All **analys**: återidentifiering (matcha partiella plåtar mot fullständiga),
klustring, mönsterdetektering, kartdashboard. En tidig skiss finns i
`bin3_prototype/` (entitets-stubbar + plåtmatchning) — **medvetet borttagen** ur
data-mimiken eftersom den härleder kunskap som meddelandena inte innehåller. Se
`bin3_prototype/README.md`.

## För utvecklaren av den centrala applikationen
- `FORMAT_SPEC.md` — fullständig specifikation av meddelandeformatet (filnamn,
  frontmatter, 7S-fält, länkningsregler, plåtformat, anropssignaler, kodning).
- `7S_frontmatter.schema.json` — JSON Schema för frontmatter. Alla 300
  exempelrapporter validerar mot det.

## Scenario
Fredsbevakning av HvSS Vällinge (~59.2622, 17.7120), inom ~3 km. 7 dygn
(lör 14 – fre 20 feb 2026), fler observationer dagtid, glesare nattetid.


## Steg 0-ändring (datamodell uppdaterad)
Datat speglar nu det bekräftade Bin 1-antagandet och pluginets behov:
- **Endast deterministiska ID:n länkas** (nummerplåtar). Beskrivande märken
  (ryggsäckar, kepsar, loggor) står som **ren prosa** i Symbol — inte wikilänkar.
- **Återkommande tells varieras i formulering** mellan observationer (samma
  ryggsäck/logga beskrivs olika), så exakt strängmatchning *inte* räcker —
  pluginet måste normalisera/matcha semantiskt (Jobb B/C).
- **`källa: bin1-intag`** sätts i frontmatter (proveniens; en av tre klasser).
- **Korroborerande placeholder-bilder**: en delmängd POI-fordonsobservationer
  med fullständig plåt får en renderad plåt-bild i `attachments/`, refererad via
  `bilagor:` + `![[...]]`. Plåten finns *även i texten* → bilden bekräftar
  (testar OCR-korroborering §6.7), detektering beror aldrig på bild.
- `ground_truth.json` bär nu dolda `tells`-id:n, sann `plate`, och
  `image_corroborates_plate` för poängsättning.
- Mataren kopierar refererade bilagor till vaultens `attachments/`.

> Bilderna är **placeholders** (renderade plåtkort), inte fotografier — de testar
> *pipelinen* (lagring, referens, vision-adapter, OCR av tydlig text), inte
> fotorealistisk bildanalys. Riktiga foton kan slotta in i samma koppling senare.
